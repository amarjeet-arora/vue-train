<template>
  <section>
    <slot></slot>
  </section>
</template>

<style scoped>
section {
  margin: 2rem;
  border: 1px solid #797979;
  padding: 1rem;
  flex: 1;
}
</style>